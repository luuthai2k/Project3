﻿using UnityEngine;

public class Continue : MonoBehaviour
{
    public int ModeSelection;
    public GameObject ContinueButton;
    public GameObject ModePanel;
    public GameObject Titles;
    public GameObject Background2;
    public GameObject Background3;
    public GameObject CashDisplay;
    public GameObject CarsPanel;
    public GameObject CarsPanelP2;
    private void Start()
    {
        Next();
    }

    public void Next ()
    {
        ModeSelection = ModeSelect.RaceMode;
        if (ModeSelection == 0)
        {
            ContinueButton.SetActive(false);
            CarsPanel.GetComponent<MoveLeftCarsPanel>().enabled = true;
            Titles.GetComponent<MoveLeftTitles>().enabled = true;
            ModePanel.GetComponent<MoveLeftModePanel>().enabled = true;
            Background2.GetComponent<FadeInBackground2>().enabled = true;
            Background3.GetComponent<FillAmount>().enabled = true;
            CashDisplay.SetActive(true);
        }
        if (ModeSelection == 1)
        {
            ContinueButton.SetActive(false);
            CarsPanel.GetComponent<MoveLeftCarsPanel>().enabled = true;
            Titles.GetComponent<MoveLeftTitles>().enabled = true;
            ModePanel.GetComponent<MoveLeftModePanel>().enabled = true;
            Background2.GetComponent<FadeInBackground2>().enabled = true;
            Background3.GetComponent<FillAmount>().enabled = true;
            CashDisplay.SetActive(true);
        }
        if (ModeSelection == 2)
        {
            ContinueButton.SetActive(false);
            CarsPanel.GetComponent<MoveLeftCarsPanel>().enabled = true;
            Titles.GetComponent<MoveLeftTitles>().enabled = true;
            ModePanel.GetComponent<MoveLeftModePanel>().enabled = true;
            Background2.GetComponent<FadeInBackground2>().enabled = true;
            Background3.GetComponent<FillAmount>().enabled = true;
            CashDisplay.SetActive(true);
        }
        if (ModeSelection == 3)
        {
            ContinueButton.SetActive(false);
            CarsPanel.GetComponent<MoveLeftCarsPanel>().enabled = true;
            Titles.GetComponent<MoveLeftTitles>().enabled = true;
            ModePanel.GetComponent<MoveLeftModePanel>().enabled = true;
            Background2.GetComponent<FadeInBackground2>().enabled = true;
            Background3.GetComponent<FillAmount>().enabled = true;
            CashDisplay.SetActive(true);
        }
    }
}
