﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Loading : MonoBehaviour
{
    public GameObject LoadingText;

	public void TextLoading ()
    {
        LoadingText.SetActive(true);
	}
	
}
